package com.example.autoscreentranslator

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.widget.ScrollView
import android.widget.TextView

class TranslationOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val textView = TextView(context).apply {
        setTextColor(Color.WHITE)
        textSize = 16f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(18, 14, 18, 14)
        setBackgroundColor(0xE6222030.toInt())
        text = "Автоперевод включён…"
    }
    private val scroll = ScrollView(context).apply {
        addView(textView)
        isVerticalScrollBarEnabled = false
    }
    private var attached = false

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP
        y = 0
    }

    fun show() {
        if (!attached) {
            windowManager.addView(scroll, params)
            attached = true
        }
    }

    fun update(text: String) {
        textView.text = text
        if (!attached) show()
    }

    fun hide() {
        if (attached) {
            try { windowManager.removeView(scroll) } catch (_: Exception) {}
            attached = false
        }
    }
}
