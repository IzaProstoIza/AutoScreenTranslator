package com.example.autoscreentranslator

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureRequestCode = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showUi()
    }

    private fun showUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF171522.toInt())
        }
        val title = TextView(this).apply {
            text = "Автоперевод экрана"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "После запуска распознаёт видимый текст и автоматически показывает перевод на русский в верхней панели."
            textSize = 16f
            setTextColor(0xFFD8D4E8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }
        val start = Button(this).apply {
            text = "Включить автоперевод"
            setOnClickListener { startTranslation() }
        }
        val stop = Button(this).apply {
            text = "Остановить перевод"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenTranslateService::class.java))
            }
        }
        val note = TextView(this).apply {
            text = "Для работы нужен системный доступ к захвату экрана. Во время сеанса Android показывает уведомление."
            textSize = 13f
            setTextColor(0xFFB7B2C8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(desc)
        root.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(note)
        setContentView(root)
    }

    private fun startTranslation() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
    }

    @Deprecated("Handled for compatibility with MediaProjection consent flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenTranslateService::class.java).apply {
                putExtra(ScreenTranslateService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenTranslateService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
            moveTaskToBack(true)
        }
    }
}
