package com.example.autoscreentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class ScreenTranslateService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "screen_translate"
        private const val NOTIFICATION_ID = 72
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private var overlay: TranslationOverlay? = null
    private val busy = AtomicBoolean(false)
    private var lastFrameAt = 0L
    private var lastOverlayText = ""
    private val translators = ConcurrentHashMap<String, Translator>()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val languageIdentifier by lazy { LanguageIdentification.getClient() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        if (projection != null) return START_NOT_STICKY

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        if (resultCode == 0 || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            startCapture()
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        workerThread = HandlerThread("screen-ocr").also { it.start() }
        worker = Handler(workerThread!!.looper)
        overlay = TranslationOverlay(this).also { it.show() }
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            if (now - lastFrameAt < 1400 || !busy.compareAndSet(false, true)) {
                try { reader.acquireLatestImage()?.close() } catch (_: Exception) {}
                return@setOnImageAvailableListener
            }
            lastFrameAt = now
            val image = try { reader.acquireLatestImage() } catch (_: Exception) { null }
            if (image == null) {
                busy.set(false)
                return@setOnImageAvailableListener
            }
            worker?.post {
                try {
                    val bitmap = imageToBitmap(image)
                    image.close()
                    if (bitmap != null) recognizeAndTranslate(bitmap)
                } catch (_: Exception) {
                    try { image.close() } catch (_: Exception) {}
                } finally {
                    busy.set(false)
                }
            }
        }, worker)

        virtualDisplay = projection?.createVirtualDisplay(
            "AutoScreenTranslator", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, worker
        )
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        if (cropped !== padded) padded.recycle()
        return cropped
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val lines = result.textBlocks.flatMap { block -> block.lines }
                    .map { it.text.trim() }
                    .filter { it.length >= 2 && it.any { c -> c.isLetter() } }
                    .distinct()
                    .take(18)
                if (lines.isEmpty()) {
                    overlay?.update("Автоперевод включён. Ожидание текста…")
                    return@addOnSuccessListener
                }
                val snapshot = lines.joinToString("\n")
                if (snapshot == lastOverlayText) return@addOnSuccessListener
                translateLines(lines)
            }
            .addOnFailureListener { }
            .addOnCompleteListener { bitmap.recycle() }
    }

    private fun translateLines(lines: List<String>) {
        languageIdentifier.identifyLanguage(lines.joinToString(" "))
            .addOnSuccessListener { language ->
                if (language == "und" || language == "ru") {
                    val text = if (language == "ru") lines.joinToString("\n") else "Не удалось определить язык текста."
                    lastOverlayText = lines.joinToString("\n")
                    overlay?.update(text)
                    return@addOnSuccessListener
                }
                val options = TranslatorOptions.Builder()
                    .setSourceLanguage(language)
                    .setTargetLanguage("ru")
                    .build()
                val translator = translators.getOrPut(language) { Translation.getClient(options) }
                translator.downloadModelIfNeeded()
                    .addOnSuccessListener {
                        val translated = ArrayList<String>()
                        fun next(index: Int) {
                            if (index >= lines.size) {
                                val display = translated.joinToString("\n")
                                lastOverlayText = lines.joinToString("\n")
                                overlay?.update(display)
                                return
                            }
                            translator.translate(lines[index])
                                .addOnSuccessListener { value ->
                                    translated.add(value)
                                    next(index + 1)
                                }
                                .addOnFailureListener {
                                    translated.add(lines[index])
                                    next(index + 1)
                                }
                        }
                        next(0)
                    }
                    .addOnFailureListener {
                        overlay?.update("Не удалось загрузить модель перевода. Подключитесь к интернету.")
                    }
            }
            .addOnFailureListener {
                overlay?.update("Не удалось определить язык текста.")
            }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Автоперевод экрана", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Уведомление активного сеанса захвата экрана" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Автоперевод экрана активен")
            .setContentText("Распознавание и перевод текста на русский")
            .setSmallIcon(android.R.drawable.ic_menu_translate)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        overlay?.hide()
        translators.values.forEach { try { it.close() } catch (_: Exception) {} }
        try { recognizer.close() } catch (_: Exception) {}
        try { languageIdentifier.close() } catch (_: Exception) {}
        workerThread?.quitSafely()
        super.onDestroy()
    }
}
